<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class EnquiryReplyimage	 extends Model
{

	protected $table = 'enquiry_reply_images';

	public $timestamps = true;


}
