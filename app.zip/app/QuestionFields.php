<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuestionFields extends Model
{
    //
}
