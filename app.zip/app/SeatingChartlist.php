<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;


class SeatingChartlist extends Model
{

	protected $table = 'seating_chart_list';

	public $timestamps = true;

}
