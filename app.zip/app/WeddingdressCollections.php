<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
use DB;

class WeddingdressCollections extends Model
{
	protected $table = 'weddingdress_collections';
	public $timestamps = true;
}