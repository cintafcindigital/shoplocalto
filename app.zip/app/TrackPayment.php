<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

class TrackPayment extends Model
{
	protected $table = 'track_payment';
}