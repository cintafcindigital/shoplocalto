<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FeaturedProfile extends Model
{
    protected $table = 'featured_profiles';
}