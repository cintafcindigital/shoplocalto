<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
use DB;

class WeddingdressProductImages extends Model
{
	protected $table = 'weddingdress_product_images';
	public $timestamps = true;
}