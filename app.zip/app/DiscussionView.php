<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class DiscussionView extends Model
{

	protected $table = 'discussion_views';

	public $timestamps = true;


}
