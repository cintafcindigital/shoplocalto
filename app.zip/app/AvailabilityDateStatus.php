<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
use DB;
class AvailabilityDateStatus extends Model
{
	protected $table = 'availability_date_status';
}