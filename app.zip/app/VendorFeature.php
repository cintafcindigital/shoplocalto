<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class VendorFeature extends Model
{
    protected $table = 'vendor_feature';
}