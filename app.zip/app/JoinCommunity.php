<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class JoinCommunity extends Model
{

	protected $table = 'join_community_groups';

	public $timestamps = true;

}
