<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WeddingStory extends Model
{
    //
}
