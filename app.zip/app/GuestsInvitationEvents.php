<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

class GuestsInvitationEvents extends Model
{
    protected $table = 'guests_invitation_events';
}