<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

class DealTypes extends Model
{
    protected $table = 'deal_types';
}