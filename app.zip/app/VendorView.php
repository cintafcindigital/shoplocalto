<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class VendorView extends Model
{

	protected $table = 'vendor_views';

	public $timestamps = true;

}