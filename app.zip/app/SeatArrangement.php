<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;


class SeatArrangement extends Model
{

	protected $table = 'seat_arrangements';

	public $timestamps = true;

}
