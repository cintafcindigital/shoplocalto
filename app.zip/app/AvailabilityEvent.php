<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
use DB;
class AvailabilityEvent extends Model
{
	protected $table = 'availability_events';
	// public $timestamps = true;
}