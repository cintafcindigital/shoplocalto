<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

class BusinessInfo extends Model
{
	protected $table = 'vendor_more_business_info';
}