<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

class PlanningToolsPages extends Model
{
	protected $table = 'planning_tools_pages';
}