<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
use DB;
class AvailabilitySetting extends Model
{
	protected $table = 'availability_setting';
	// public $timestamps = true;
}