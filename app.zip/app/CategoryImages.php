<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

class CategoryImages extends Model
{
    protected $table = 'categories_images';
}