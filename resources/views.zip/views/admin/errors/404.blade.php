@extends('layouts.app')
@section('content')
 <section class="content-header">
      <h1>
           Dashboard       
      </h1>
    <ol class="breadcrumb">         
            <li><a href="{{url('home')}}"><i class="fa fa-dashboard"></i>Dashboard</a></li>
    </ol>
    </section>
 <section class="content">
     <div class="row">
                <h1> 404 Page</h1>
     </div>
</section>
@endsection
