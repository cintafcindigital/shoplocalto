<html>
<body>
<table width="100%" cellpadding="0" cellspacing="0" style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;background-color:#f5f8fa;margin:0;padding:0;width:100%">
   <tbody>
      <tr>
         <td align="center" style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box">
            <table width="100%" cellpadding="0" cellspacing="0" style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;margin:0;padding:0;width:100%">
               <tbody>
                  <tr>
                     <td style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;padding:25px 0;text-align:center">
                        <a href="#">
                           <img src="{{ asset('public/images/logo.png') }}" width="50%" alt="My Health Squad Logo" style="width: 50%;">
                        </a>
                     </td>
                  </tr>
                  <tr>
                     <td width="100%" cellpadding="0" cellspacing="0" style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;background-color:#ffffff;border-bottom:1px solid #edeff2;border-top:1px solid #edeff2;margin:0;padding:0;width:100%">
                        <table align="center" width="60%" cellpadding="0" cellspacing="0" style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;background-color:#ffffff;margin:0 auto;padding:0;width:60%">
                           <tbody>
                              <tr>
                                 <td style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;padding:35px">
                                    <span class="im">
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'>Bonjour !</p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'>&nbsp;</p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'>Notre &eacute;quipe examinera votre fiche sous peu et d&egrave;s qu&#39;elle sera op&eacute;rationnelle, nous vous en informerons. N&#39;h&eacute;sitez pas &agrave; nous contacter &agrave; tout moment si vous avez d&#39;autres questions.</p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'>&nbsp;</p>
                                       <p><strong><span style='font-size:15px;line-height:115%;font-family:"Arial","sans-serif";'>Mon &Eacute;quipe Sant&eacute;</span></strong></p>
                                       <div id="_com_1" language="JavaScript"><br></div>
                                       <p><span style='font-size:12px;line-height:115%;font-family:"Helvetica Neue";'>Se d&eacute;sabonner des e-mails de Mon &Eacute;quipe Sant&eacute; (<a href="" style="color: #1155CC;" target="_blank">lien</a>)</span></p>
                                    </span>
                                    
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </td>
                  </tr>
                  <tr>
                     <td style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box">
                        <table align="center" width="570" cellpadding="0" cellspacing="0" style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;margin:0 auto;padding:0;text-align:center;width:570px">
                           <tbody>
                              <tr>
                                 <td align="center" style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;padding:35px">
                                    <p style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;line-height:1.5em;margin-top:0;color:#aeaeae;font-size:12px;text-align:center">&copy; {{date('Y')}} <span class="il">My </span> <span class="il">Health</span> Squad. All rights reserved.</p>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
   </tbody>
</table>
</body>
</html>