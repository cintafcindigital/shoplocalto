<html>
<body>
<table width="100%" cellpadding="0" cellspacing="0" style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;background-color:#f5f8fa;margin:0;padding:0;width:100%">
   <tbody>
      <tr>
         <td align="center" style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box">
            <table width="100%" cellpadding="0" cellspacing="0" style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;margin:0;padding:0;width:100%">
               <tbody>
                  <tr>
                     <td style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;padding:25px 0;text-align:center">
                        <a href="#">
                           <img src="{{ asset('public/images/logo.png') }}" width="50%" alt="My Health Squad Logo" style="width: 50%;">
                        </a>
                     </td>
                  </tr>
                  <tr>
                     <td width="100%" cellpadding="0" cellspacing="0" style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;background-color:#ffffff;border-bottom:1px solid #edeff2;border-top:1px solid #edeff2;margin:0;padding:0;width:100%">
                        <table align="center" width="60%" cellpadding="0" cellspacing="0" style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;background-color:#ffffff;margin:0 auto;padding:0;width:60%">
                           <tbody>
                              <tr>
                                 <td style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;padding:35px">
                                    <span class="im">
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'><strong>Bonjour!</strong></p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'><strong>&nbsp;</strong></p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'><strong>&nbsp;</strong></p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'><strong>Un client potentiel a demand&eacute; des informations sur votre entreprise via votre inscription gratuite sur Mon &Eacute;quipe Sant&eacute;. Si vous souhaitez r&eacute;clamer le client et en obtenir davantage, veuillez cliquer ici pour voir les abonnements. (lien vers la page R&eacute;clamation / Mise &agrave; niveau).</strong></p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'><strong>&nbsp;</strong></p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'><strong>Les d&eacute;tails du client potentiel comprendront:</strong></p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'><strong>-Nom</strong></p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'><strong>-Email</strong></p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'><strong>-T&eacute;l&eacute;phone</strong></p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'><strong>-Produit, service ou traitement recherch&eacute;</strong></p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'><strong>-D&eacute;tails de la demande sp&eacute;cifique</strong></p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'><strong>&nbsp;</strong></p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'><strong>Mon &Eacute;quipe Sant&eacute; est une &eacute;quipe qui se distingue par son exclusivit&eacute; et son int&eacute;r&ecirc;t sans cesse grandissant par la sant&eacute;. Nous serions heureux de vous aider &agrave; d&eacute;velopper votre entreprise et &agrave; &eacute;tablir des liens significatifs.</strong></p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'><strong>&nbsp;</strong></p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'><strong>Vivez en bonne sant&eacute; et prosp&eacute;rez!</strong></p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'><strong>&nbsp;</strong></p>
                                       <p style='margin:0in;margin-bottom:.0001pt;line-height:115%;font-size:15px;font-family:"Arial","sans-serif";'><strong>&nbsp;</strong></p>
                                       <p><strong><span style='font-size:15px;line-height:115%;font-family:"Arial","sans-serif";'>Mon &Eacute;quipe Sant&eacute;.</span></strong></p>
                                       <div id="_com_1" language="JavaScript"><br></div>
                                       <p><span style='font-size:12px;line-height:115%;font-family:"Helvetica Neue";'>Se d&eacute;sabonner des e-mails de Mon &Eacute;quipe Sant&eacute; (<a href="" style="color: #1155CC;" target="_blank">lien</a>)</span></p>
                                    </span>
                                    
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </td>
                  </tr>
                  <tr>
                     <td style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box">
                        <table align="center" width="570" cellpadding="0" cellspacing="0" style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;margin:0 auto;padding:0;text-align:center;width:570px">
                           <tbody>
                              <tr>
                                 <td align="center" style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;padding:35px">
                                    <p style="font-family:Avenir,Helvetica,sans-serif;box-sizing:border-box;line-height:1.5em;margin-top:0;color:#aeaeae;font-size:12px;text-align:center">&copy; {{date('Y')}} <span class="il">My </span> <span class="il">Health</span> Squad. All rights reserved.</p>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
   </tbody>
</table>
</body>
</html>