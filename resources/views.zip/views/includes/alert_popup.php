<div class="modal fade request-info" id="myModalWarning" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header text-center">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4><i class="fa fa-warning"></i> Warning </h4>
      </div>
      <div class="modal-body">
        <form class="cus-login-form record-details text-left clearfix" name="frmContactoInline" action="" method="post" >
            <div class="col-sm-12">
               <div class="form-group">
                    <div class="facebook-login text-center">
                        <br><p class="cus-login-msg" style="font-size:18px;">You must specify your search criteria.</p>
                    </div><!-- Facebook Login -->
                </div>
            </div>
            <div id="login-msg"></div>           
        </form>
      </div>
    </div>
  </div>
</div><!-- Popup -->