<div class="m_-816630429745570621body" style="width:100%!important;min-width:100%;color:#616161;font-family:Helvetica,Arial,sans-serif;font-weight:normal;text-align:left;font-size:14px;line-height:21px" bgcolor="#f6f3f2">
    <table width="100%" bgcolor="#f6f3f2">
        <tbody>
            <tr>
                <td valign="top" align="center">
                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                        <tbody>
                            <tr>
                                <td style="padding:20px 0;height:38px" valign="top" height="38" align="center">
                                    <center style="width:100%;min-width:580px">
                                        <a border="0" href="https://www.weddingwire.ca/mail-TraceClick.php?tipo=TOOLS_REQUEST_CONFIRM&amp;durl=http%3A%2F%2Fwww.weddingwire.ca&amp;utm_source=bodas_tools_request_confirm&amp;utm_medium=email&amp;utm_campaign=bodas_tools_request_confirm&amp;utm_idTrack=19751450" target="_blank">
                                            <img src="https://ci6.googleusercontent.com/proxy/HdZRRvnm79CZnFZEUO45B9LxK32ZL66a97b2KxNG44jtzmDI1nIwkvHh1uCMpB-bWYTARIbiz1vaH6EuOaw-P4NW1yVorN6627hqTQw9Hf-Ac0GNe3E263oA=s0-d-e1-ft#https://cdn1.weddingwire.ca/assets/img/logos/mails/main-layout-logo.png" style="max-width:100%;margin:0px auto 0px;height:38px!important;max-height:38px!important" alt="" class="CToWUd" height="38" border="0" align="middle">
                                        </a>
                                    </center>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="m_-816630429745570621cr" style="width:580px;border-radius:4px" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF">
                        <tbody>
                            <tr>
                                <td valign="top" align="center">
                                    <table style="border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="font-family:'Avenir Next',Avenir,Arial,sans-serif;font-size:30px;color:#2b2b2b;font-weight:600;padding:40px 30px 10px;line-height:1.2" align="center"> Maria and cesario </td>
                                            </tr>
                                            <tr>
                                                <td style="font-family:'Avenir Next',Avenir,Arial,sans-serif;font-size:16px;color:#2b2b2b;font-weight:500;padding:10px 30px 30px" align="center"> Friday 06 of March of 2015 </td>
                                            </tr>
                                            <tr>
                                                <td align="center">
                                                    <img src="https://ci6.googleusercontent.com/proxy/3QnzSmMU_3BelSyNIaw9jGYWeLIUTWRfndtnXr1CWPKszFR5AlgGp6D5GH_sRQRpnOBI44s2fyPHGaNN8qUrQWTI0gTB43ynfKBHsngDsHA=s0-d-e1-ft#https://cdn1.weddingwire.ca/img/mail/requestConfirm-en_CA.gif" style="height:100px!important" class="CToWUd a6T" tabindex="0" height="100">
                                                    <div class="a6S" dir="ltr" style="opacity: 0.01; left: 540.867px; top: 291px;">
                                                        <div id=":tu" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" role="button" tabindex="0" aria-label="Download attachment " data-tooltip-class="a1V" data-tooltip="Download">
                                                            <div class="aSK J-J5-Ji aYr"></div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td align="center">
                                                    <table style="max-width:400px" width="100%" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="padding:20px 30px 10px 30px;color:#444444;line-height:1.7em" valign="top" align="center"> You’re invited! Please RSVP to let us know if you’re able to attend. </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="m_-816630429745570621bc m_-816630429745570621fw m_-816630429745570621rw" style="padding:10px 30px 30px" valign="top" align="center">
                                                    <a style="display:inline-block;color:#ffffff;text-decoration:none;padding:0;border-radius:3px;max-width:100%;overflow:hidden" href="https://www.weddingwire.ca/mail-TraceClick.php?tipo=TOOLS_REQUEST_CONFIRM&amp;durl=https%3A%2F%2Fwww.weddingwire.ca%2Ftools%2FGuestsRequestConfirmForm%3Fconfirm%3D8181d95365daeed328c4f5320b4ad8fd8cfcf157ace928e249e8ca7064182a7f6b208621ee918579MTIxOTA2&amp;utm_source=bodas_tools_request_confirm&amp;utm_medium=email&amp;utm_campaign=bodas_tools_request_confirm&amp;utm_idTrack=19751450" target="_blank">
                                                        <table style="border-spacing:0;border-collapse:collapse;vertical-align:top;display:inline-block;padding:0">
                                                            <tbody>
                                                                <tr>
                                                                    <td style="border-collapse:collapse!important;vertical-align:top;color:#ffffff;display:block;width:auto!important;background:#19b5bc;border:1px solid #19b5bc;margin:0;padding:10px 15px;border-radius:3px" valign="top" bgcolor="#19b5bc">
                                                                        <span style="text-decoration:none;color:#ffffff;font-weight:bold">
                                                                            <a style="color:#ffffff;text-decoration:none;padding:0;border-radius:2px;max-width:100%" href="https://www.weddingwire.ca/mail-TraceClick.php?tipo=TOOLS_REQUEST_CONFIRM&amp;durl=https%3A%2F%2Fwww.weddingwire.ca%2Ftools%2FGuestsRequestConfirmForm%3Fconfirm%3D8181d95365daeed328c4f5320b4ad8fd8cfcf157ace928e249e8ca7064182a7f6b208621ee918579MTIxOTA2&amp;utm_source=bodas_tools_request_confirm&amp;utm_medium=email&amp;utm_campaign=bodas_tools_request_confirm&amp;utm_idTrack=19751450" target="_blank"> RSVP </a>
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </a>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <table width="100%" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="padding:20px 0 0 0" valign="top" align="center">
                                                                    <center style="width:100%"><img src="https://ci4.googleusercontent.com/proxy/oqAaTB5UDNzLy-SNxCrdZB_V3XG-UP0LtSsZPtsmXCXOaMkpaIPZ1wtBnKZRnxhkRs9riBfzfNUfxvYrZ381uLgX7kH0z8pkrNWEHSU=s0-d-e1-ft#https://cdn1.weddingwire.ca/assets/img/mails/gen_heart.gif" style="max-width:100%" class="CToWUd" width="55" align="middle"></center>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <table width="100%" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="font-family:Helvetica,Arial,sans-serif;font-size:14px;font-weight:300;color:#7f7f7f;padding:10px 0 20px 0" valign="top" align="center"> Thank you!<br> Maria &amp; cesario </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <table style="border-top:1px solid #d9d9d9;width:580px">
                                                        <tbody>
                                                            <tr>
                                                                <td style="padding:30px 0 30px 70px" align="right">
                                                                    <img style="width:40px;height:auto;padding-right:12px" src="https://ci3.googleusercontent.com/proxy/4BB5BEAh5hbit__dp-3tbUyc6e8PUuuQjzTeYO05HcRqiecVAfrRQESHifGhAEN4Q-SZ3-EIruyMzIgsvewbPCweS2KaIVxO1HVVQ5h-lhVwOF05mrbNR18W2Q=s0-d-e1-ft#https://cdn1.weddingwire.ca/assets/img/tools/invitations/nav-wedsite.png" class="CToWUd" width="75">
                                                                </td>
                                                                <td style="overflow:hidden;font-size:12px;line-height:15px">
                                                                    <span>Visit our website</span><br>
                                                                    <a style="text-decoration:underline;color:#444444" href="https://www.weddingwire.ca/web/maria-and-cesario?utm_source=bodas_tools_request_confirm&amp;utm_medium=email&amp;utm_campaign=bodas_tools_request_confirm&amp;utm_idTrack=19751450" target="_blank">https://www.weddingwire.ca/<wbr>web/maria-and-cesario</a>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="m_-816630429745570621cr" style="width:580px" cellspacing="0" cellpadding="0">
                        <tbody>
                            <tr>
                                <td style="padding:15px 0" valign="top" align="left">
                                    <table width="100%" cellspacing="0" cellpadding="0">
                                        <tbody>
                                            <tr>
                                                <td style="font-size:11px;color:#666666" align="center">
                                                    <p>
                                                        <a href="https://www.weddingwire.ca?utm_source=bodas_tools_request_confirm&amp;utm_medium=email&amp;utm_campaign=bodas_tools_request_confirm&amp;utm_idTrack=19751450" target="_blank">www.weddingwire.ca</a>, Wedding Planner, S.L.U., Av. Alcalde Barnils, 64-68, 4th floor - Sant Cugat del Vallès (Barcelona, Spain)
                                                    </p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
</div>