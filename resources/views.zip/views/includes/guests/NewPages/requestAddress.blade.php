<div class="m_5621622316345554329body" style="width:100%!important;min-width:100%;color:#616161;font-family:Helvetica,Arial,sans-serif;font-weight:normal;text-align:left;font-size:14px;line-height:21px" bgcolor="#f6f3f2">
    <table width="100%" bgcolor="#f6f3f2">
        <tbody>
            <tr>
                <td valign="top" align="center">
                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                        <tbody>
                            <tr>
                                <td style="padding:20px 0;height:38px" valign="top" height="38" align="center">
                                    <center style="width:100%;min-width:580px">
                                        <a border="0" href="https://www.weddingwire.ca/mail-TraceClick.php?tipo=TOOLS_REQUEST_CONFIRM_ADDRESS&amp;durl=http%3A%2F%2Fwww.weddingwire.ca&amp;utm_source=bodas_tools_request_confirm_address&amp;utm_medium=email&amp;utm_campaign=bodas_tools_request_confirm_address&amp;utm_idTrack=19751452" target="_blank">
                                            <img src="https://ci6.googleusercontent.com/proxy/HdZRRvnm79CZnFZEUO45B9LxK32ZL66a97b2KxNG44jtzmDI1nIwkvHh1uCMpB-bWYTARIbiz1vaH6EuOaw-P4NW1yVorN6627hqTQw9Hf-Ac0GNe3E263oA=s0-d-e1-ft#https://cdn1.weddingwire.ca/assets/img/logos/mails/main-layout-logo.png" style="max-width:100%;margin:0px auto 0px;height:38px!important;max-height:38px!important" alt="" class="CToWUd" height="38" border="0" align="middle">
                                        </a>
                                    </center>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="m_5621622316345554329cr" style="width:580px;border-radius:4px" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF">
                        <tbody>
                            <tr>
                                <td valign="top" align="center">
                                    <table style="border-collapse:collapse" width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="text-align:center;padding:40px 30px" align="center">
                                                    <div></div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="font-family:'Avenir Next',Avenir,Arial,sans-serif;font-size:20px;color:#222222;padding:0 30px 10px" align="center"> Address request from </td>
                                            </tr>
                                            <tr>
                                                <td style="font-family:'Avenir Next',Avenir,Arial,sans-serif;font-size:30px;color:#fa626f;font-weight:600;padding:20px 30px 50px;line-height:1.5" align="center"> Maria and cesario </td>
                                            </tr>
                                            <tr>
                                                <td style="max-width:400px;padding-top:50px;border-top:1px solid #ddd;padding-bottom:20px" align="center"> We're getting married on </td>
                                            </tr>
                                            <tr>
                                                <td style="font-family:'Avenir Next',Avenir,Arial,sans-serif;font-size:20px;color:#2b2b2b;font-weight:600;padding:10px 30px 30px" align="center"> Friday 06 of March of 2015 </td>
                                            </tr>
                                            <tr>
                                                <td style="max-width:400px" align="center"> and would love to send you an invitation! </td>
                                            </tr>
                                            <tr>
                                                <td align="center">
                                                    <table style="max-width:400px" width="100%" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="padding:20px 30px 10px 30px;color:#444444;line-height:1.7em" valign="top" align="center"> Hi,<br> As you may know, on March 6...<br> <br> We're getting married!<br> <br> We would love for you to come and we want to make sure you receive our invitation. Kindly confirm your address using the button below. </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="m_5621622316345554329bc m_5621622316345554329fw m_5621622316345554329rw" style="padding:10px 30px 30px" valign="top" align="center">
                                                    <a style="display:inline-block;color:#ffffff;text-decoration:none;padding:0;border-radius:3px;max-width:100%;overflow:hidden" href="https://www.weddingwire.ca/mail-TraceClick.php?tipo=TOOLS_REQUEST_CONFIRM_ADDRESS&amp;durl=https%3A%2F%2Fwww.weddingwire.ca%2Ftools%2FGuestsRequestAddressForm%3Fconfirm%3D44ebe42cd12794a113c3b9f314326c0e5edb11132230e2778eac53af4d8c23e75645bc7f3be50ae2MTIxOTA2&amp;utm_source=bodas_tools_request_confirm_address&amp;utm_medium=email&amp;utm_campaign=bodas_tools_request_confirm_address&amp;utm_idTrack=19751452" target="_blank">
                                                        <table style="border-spacing:0;border-collapse:collapse;vertical-align:top;display:inline-block;padding:0">
                                                            <tbody>
                                                                <tr>
                                                                    <td style="border-collapse:collapse!important;vertical-align:top;color:#ffffff;display:block;width:auto!important;background:#19b5bc;border:1px solid #19b5bc;margin:0;padding:10px 15px;border-radius:3px" valign="top" bgcolor="#19b5bc">
                                                                        <span style="text-decoration:none;color:#ffffff;font-weight:bold">
                                                                            <a style="color:#ffffff;text-decoration:none;padding:0;border-radius:2px;max-width:100%" href="https://www.weddingwire.ca/mail-TraceClick.php?tipo=TOOLS_REQUEST_CONFIRM_ADDRESS&amp;durl=https%3A%2F%2Fwww.weddingwire.ca%2Ftools%2FGuestsRequestAddressForm%3Fconfirm%3D44ebe42cd12794a113c3b9f314326c0e5edb11132230e2778eac53af4d8c23e75645bc7f3be50ae2MTIxOTA2&amp;utm_source=bodas_tools_request_confirm_address&amp;utm_medium=email&amp;utm_campaign=bodas_tools_request_confirm_address&amp;utm_idTrack=19751452" target="_blank"> Update address </a>
                                                                        </span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </a>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <table width="100%" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="padding:20px 0 0 0" valign="top" align="center">
                                                                    <center style="width:100%"><img src="https://ci4.googleusercontent.com/proxy/oqAaTB5UDNzLy-SNxCrdZB_V3XG-UP0LtSsZPtsmXCXOaMkpaIPZ1wtBnKZRnxhkRs9riBfzfNUfxvYrZ381uLgX7kH0z8pkrNWEHSU=s0-d-e1-ft#https://cdn1.weddingwire.ca/assets/img/mails/gen_heart.gif" style="max-width:100%" class="CToWUd" width="55" align="middle"></center>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <table width="100%" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td style="font-family:Helvetica,Arial,sans-serif;font-size:14px;font-weight:300;color:#7f7f7f;padding:10px 0 20px 0" valign="top" align="center"> Thank you!<br> Maria &amp; cesario </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="m_5621622316345554329cr" style="width:580px" cellspacing="0" cellpadding="0">
                        <tbody>
                            <tr>
                                <td style="padding:15px 0" valign="top" align="left">
                                    <table width="100%" cellspacing="0" cellpadding="0">
                                        <tbody>
                                            <tr>
                                                <td style="font-size:11px;color:#666666" align="center">
                                                    <p>
                                                        <a href="https://www.weddingwire.ca?utm_source=bodas_tools_request_confirm_address&amp;utm_medium=email&amp;utm_campaign=bodas_tools_request_confirm_address&amp;utm_idTrack=19751452" target="_blank">www.weddingwire.ca</a>, Wedding Planner, S.L.U., Av. Alcalde Barnils, 64-68, 4th floor - Sant Cugat del Vallès (Barcelona, Spain)
                                                    </p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
</div>