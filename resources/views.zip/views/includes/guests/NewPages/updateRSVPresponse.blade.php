<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Perfect Wedding Day</title>
    <meta name="robots" content="all">
    <meta name="distribution" content="global">
    <meta name="rating" content="general">
    <meta name="pbdate" content="2:35:58 06/12/2019">
    <link rel="canonical" href="https://www.weddingwire.ca/tools/GuestsRequestAddressForm">
    <link rel="alternate" href="android-app://ca.weddingwire.launcher/weddingwireca/m.weddingwire.ca/tools/GuestsRequestAddressForm">
    <link rel="stylesheet" href="https://www.weddingwire.ca/css/css-nossl-sf-sui-20191204-01CA1067142-1_www_m_-phoenix/base.css">
    <link rel="stylesheet" href="https://www.weddingwire.ca/css/css-nossl-sf-sui-20191204-01CA1067142-1_www_m_-migrate/migrate,phoenix/landings_dash_user,phoenix/tools,phoenix/sprite_set_tools_navigation.css">
    <script type="text/javascript" async="" src="https://www.google-analytics.com/plugins/ua/ec.js"></script>
    <script async="" src="https://s.pinimg.com/ct/lib/main.532239b0.js"></script>
    <script type="text/javascript" async="" src="https://www.google.com/pagead/conversion_async.js"></script>
    <script src="//bat.bing.com/bat.js" async=""></script>
    <script async="" src="https://s.pinimg.com/ct/core.js"></script>
    <script src="https://connect.facebook.net/signals/config/1981600325399047?v=2.9.14&amp;r=stable" async=""></script>
    <script async="" src="https://connect.facebook.net/en_US/fbevents.js"></script>
    <script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-NS2FXVG&amp;gtm_auth=dK0IG2VXNz4urM63FZQZog&amp;gtm_preview=env-2&amp;gtm_cookies_win=x"></script>
    <script async="" defer="" src="https://sb.scorecardresearch.com/beacon.js"></script>
    <script type="text/javascript" async="" defer="" src="https://ssl.google-analytics.com/ga.js"></script>
    <script async="" src="//www.google-analytics.com/analytics.js"></script>
    <script src="https://cdn1.weddingwire.ca/js/js-nossl-sf-sui-20191204-01CA1067142-1_www_m_-common.js"></script>
    <script src="https://cdn1.weddingwire.ca/js/js-nossl-sf-sui-20191204-01CA1067142-1_www_m_-tools_dash_guest,tools_dash_contacts,tools_dash_tables,tools,wedding_dash_deals.js"></script>
    <script>
        var internalTrackingService = internalTrackingService || {
            triggerSubmit : function() {},
            triggerAbandon : function() {},
            loaded : false
        };
    </script>
    <script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/945252265/?random=1575617758804&amp;cv=9&amp;fst=1575617758804&amp;num=1&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=768&amp;u_w=1366&amp;u_ah=735&amp;u_aw=1366&amp;u_cd=24&amp;u_his=1&amp;u_tz=330&amp;u_java=false&amp;u_nplug=1&amp;u_nmime=2&amp;gtm=2oaav9&amp;sendb=1&amp;ig=0&amp;data=event%3Dgtag.config&amp;frm=0&amp;url=https%3A%2F%2Fwww.weddingwire.ca%2Ftools%2FGuestsRequestAddressForm%3Fconfirm%3D44ebe42cd12794a113c3b9f314326c0e5edb11132230e2778eac53af4d8c23e75645bc7f3be50ae2MTIxOTA2%26utm_source%3Dbodas_tools_request_confirm_address%26utm_medium%3Demail%26utm_campaign%3Dbodas_tools_request_confirm_address&amp;ref=https%3A%2F%2Fmail.google.com%2Fmail%2Fu%2F1%2F&amp;tiba=Weddings%2C%20Wedding%20-%20Weddingwire.ca&amp;hn=www.google.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script>
    <script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/945252265/?random=1575617758807&amp;cv=9&amp;fst=1575617758807&amp;num=1&amp;userId=u701165&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=768&amp;u_w=1366&amp;u_ah=735&amp;u_aw=1366&amp;u_cd=24&amp;u_his=1&amp;u_tz=330&amp;u_java=false&amp;u_nplug=1&amp;u_nmime=2&amp;gtm=2oaav9&amp;sendb=1&amp;ig=0&amp;data=event%3Dpage_view%3BAPP_CORE%3D1%3BAPP_DRESSES%3D0%3BAPP_WEDSHOOTS%3D1%3BTOOLS_LEAD%3D1%3BTOOLS_VENDORS_LEAD%3D1%3BTOOLS_CHECKLIST_LEAD%3D1%3BTOOLS_LISTA_CREATED%3D0%3BTOOLS_GUESTS_LEAD%3D1%3BTOOLS_TABLES_LEAD%3D1%3BTOOLS_BUDGET_LEAD%3D1%3BCOMMUNITY_LEAD%3D0%3BMARRIED%3D1%3BLOGGED%3D1%3BEMPRESA%3D0%3BEMPRESA_CATEGORY%3D0&amp;frm=0&amp;url=https%3A%2F%2Fwww.weddingwire.ca%2Ftools%2FGuestsRequestAddressForm%3Fconfirm%3D44ebe42cd12794a113c3b9f314326c0e5edb11132230e2778eac53af4d8c23e75645bc7f3be50ae2MTIxOTA2%26utm_source%3Dbodas_tools_request_confirm_address%26utm_medium%3Demail%26utm_campaign%3Dbodas_tools_request_confirm_address&amp;ref=https%3A%2F%2Fmail.google.com%2Fmail%2Fu%2F1%2F&amp;tiba=Weddings%2C%20Wedding%20-%20Weddingwire.ca&amp;hn=www.google.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script>
</head>
<body>
    <div class="header">
        <div class="mt30 text-center">
            <a href="https://www.weddingwire.ca" title="Weddings">
                <img src="https://cdn1.weddingwire.ca/assets/img/logos/gen_logoHeader.svg" alt="www.weddingwire.ca" height="30">
            </a>
        </div>
    </div>
    <div class="rsvp">
        <h2 class="rsvp__title">Maria and cesario</h2>
        <p class="text-center">request that you confirm your attendance</p>    
        <form class="app-tools-rsvp" data-type="confirm">
            <input type="hidden" name="confirm" value="35c98fee4b60d9a412a9646349d3977f8c436204544a53b03297f00cd9cd0fdb712659abac8dba75MTIxOTA2">
            <input type="hidden" name="idUser" value="701165">
            <input type="hidden" name="eventsWithMenu" value="1078841">
            <input type="hidden" name="idContactParent" value="8033973">
            <input type="hidden" name="token" value="NGM2MTFiMGM3ODU5YWVhYTgxZWVhYTRmNWI1YzYwM2Q=">
            <div class="rsvp__box">
                <p class="rsvp__eventTitle">Wedding</p>
                <div class="p20">
                    <div class="rsvpForm">
                        <div class="rsvpForm__column"><p>fghfgh ghjgj</p></div>
                        <div class="rsvpForm__column rsvpForm__column--switch">
                            <div class="app-textfield-validate selectSwitch">
                                <label class="app-tools-switch selectSwitch__item" data-color="green">
                                    <input class="app-tools-rsvp-switch app-not-icheck" type="radio" name="rsvp_response" value="1"> Confirm
                                </label>
                                <label class="app-tools-switch selectSwitch__item" data-color="red">
                                    <input class="app-tools-rsvp-switch app-not-icheck" type="radio" name="rsvp_response" value="2"> Cannot attend
                                </label>
                            </div>
                        </div>
                        <div class="rsvpForm__column">
                            <div class="app-input-select input-select input-group-line input-group-line--noMargin app-tools-rsvp-select-menu dnone">
                                <span class="app-input-label input-select-label">Select a menu</span>
                                <div class="app-input-dropdown input-select-dropdown" id="selectMenu" data-msgerror="Please select your meal choice.">
                                    <ul>
                                        <li data-value="1861867">Beef</li>
                                        <li data-value="1861869">Chicken</li>
                                        <li data-value="1861877">Child Meal</li>
                                        <li data-value="1861871">Fish</li>
                                        <li data-value="1861873">Lamb</li>
                                        <li data-value="1861879">Other</li>
                                        <li data-value="3056751">test menu</li>
                                        <li data-value="1861875">Vegetarian</li>
                                    </ul>
                                </div>
                                <input class="app-input-hidden" type="hidden" name="menu-1078841-8033973">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <p class="strong">Leave a message for the couple</p>
            <div class="input-group">
                <textarea name="comentario" rows="3" placeholder="Message"></textarea>
            </div>
            <div class="mt15 mb25 text-center">
                <input class="btn-flat red" type="submit" value="Send response">
            </div>
        </form>
    </div>
    <div class="layout-auth-footer">
        <ul>
            <li class="pure-u"><a rel="nofollow" href="https://www.weddingwire.ca/users-signup.php">Sign up with WeddingWire</a></li>
            <li class="pure-u"><a rel="nofollow" href="https://www.weddingwire.ca/emp-Alta.php">Are you a vendor?</a></li>
            <li class="pure-u"><a rel="nofollow" href="https://www.weddingwire.ca/contactar.php">Contact Us</a></li>
            <li class="pure-u"><a rel="nofollow" href="https://www.weddingwire.ca/legal-terms.php">Terms of Use</a></li>
            <li class="pure-u"><a rel="nofollow" href="https://www.weddingwire.ca/legal/privacy.php">Privacy Policy</a></li>
            <li class="pure-u"><a rel="nofollow" href="https://www.weddingwire.ca/about-us.php">About Us</a></li>
        </ul>
        <p class="layout-auth-footer-copyright">© 2007 - 2019 Perfect Wedding Day </p>
    </div>
    <div id="app-common-layer" class="modal fade dnone" tabindex="-1" role="dialog" aria-hidden="true"></div>
    <script>
    (function (w) {
        w.desktopInMobile = "0";
    })(window);
    </script>
    <div id="app-pusher-vendors-users-notification-alert" class="pusher-notification dnone"></div>
    <div id="app-chat-container" class="pusher-container"></div>
    <script>
    $(document).ready(function() {
        PusherManager.init('{\u0022id\u0022:\u0022701165\u0022,\u0022name\u0022:\u0022Maria\u0022,\u0022avatar\u0022:\u0022https:\\/\\/cdn0.weddingwire.ca\\/usr\\/1\\/1\\/6\\/5\\/utxp_701165.jpg?r=82333\u0022,\u0022avatarSvg\u0022:null,\u0022type\u0022:\u0022user\u0022}', false, {
            disableChat: true,
            disableUserVendorNotifications: false
        });
        $('body').on('click','.app-tools-rsvp-switch',function(){
            if($(this).val() == 1) {
                $('.app-tools-rsvp-select-menu').removeClass('dnone');
            } else {
                $('.app-tools-rsvp-select-menu').addClass('dnone');
            }
        });
    });
    </script>
    <script>(function(i,r){i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)}})(window,'ga');var analyticsManager = (function() {var _storedAnalyticsEvents = [];function queueEvent(func) {if (!!window.ga && !!ga.create) {func();} else {_storedAnalyticsEvents.push(func);}}function trackQueuedEvents() {for (var k in _storedAnalyticsEvents) {if (_storedAnalyticsEvents.hasOwnProperty(k)) {_storedAnalyticsEvents[k]();}}}return {queueEvent : queueEvent,trackQueuedEvents : trackQueuedEvents,}})();</script>
    <script>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.onload=analyticsManager.trackQueuedEvents;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','//www.google-analytics.com/analytics.js','ga');</script>
    <script>ga("create", "UA-692627-108", {"userId":"u701165"});ga('set', 'dimension1', 'logado');ga('set', 'dimension11', '2015-03-06');ga('set', 'dimension12', '2019-02-11 08:17:07');ga('set', 'dimension13', '1');ga('set', 'dimension14', '-1736');ga('set', 'dimension6', 'u701165');ga('set', 'dimension5', '(not set)');var customDimension = document.getElementsByClassName('app-custom-dimension');if (customDimension.length) {Array.prototype.forEach.call(customDimension, function(el, i){ga('set', el.getAttribute('data-name'), '' + el.getAttribute('data-value'));});}try {parent.ga('set', 'dimension19', window.localStorage.getItem('timestampCustomDimension'));} catch (err) {}ga(function(tracker) {var clientId = tracker.get('clientId');ga('set', 'dimension7', clientId);});ga("send", "pageview");</script>
    <script class="app-ecommerce-script">parent.ga('require', 'ec');</script>
    <script class="app-ecommerce-script">try {parent.ga('set', 'dimension19', window.localStorage.getItem('timestampCustomDimension'));} catch (err) {}</script>
    <script>
        var reduced = '';
        var _gaq = _gaq || [];
        window.asyncAnalytics = true;
        _gaq.push(['_setAccount', 'UA-65181856-1']);
        _gaq.push(['_setCustomVar',1,'UserLoginInfo','logado',2]);
        _gaq.push(['_setCustomVar',11,'user_wedding_date','2015-03-06',1]);
        _gaq.push(['_setCustomVar',12,'user_signup_date','2019-02-11 08:17:07',1]);
        _gaq.push(['_setCustomVar',13,'user_role','1',1]);
        _gaq.push(['_setCustomVar',14,'user_countdown','-1736',1]);
        _gaq.push(['_setCustomVar',3,'MailVisitor','TOOLS_REQUEST_CONFIRM_ADDRESS',2]);
        _gaq.push(['_setSiteSpeedSampleRate', 10]);
        _gaq.push(['_trackPageview']);
        (function() {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;ga.defer = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
        })();
        $(document).ready(function() {
            analyticsManager.trackQueuedEvents();
        });
    </script>
    <script>
        var _comscore = _comscore || [];
        _comscore.push({ c1: "2", c2: "6156116" });
        (function() {
            var s = document.createElement("script"), el = document.getElementsByTagName("script")[0]; s.async = true; s.defer = true;
            s.src = (document.location.protocol == "https:" ? "https://sb" : "http://b") + ".scorecardresearch.com/beacon.js";
            el.parentNode.insertBefore(s, el);
        })();
    </script>
    <script>
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({"ga_uuid":"UA-692627-108","internal_userid":"701165","impression_set_id":1575617758,"is_mobile":0});
    </script>
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl+ '&gtm_auth=dK0IG2VXNz4urM63FZQZog&gtm_preview=env-2&gtm_cookies_win=x';f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-NS2FXVG');</script>
    <noscript>
    <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NS2FXVG&gtm_auth=dK0IG2VXNz4urM63FZQZog&gtm_preview=env-2&gtm_cookies_win=x"
    height="0" width="0" style="display:none;visibility:hidden"></iframe>
    </noscript>
    <script>
    $(document).ready(function() {
        trackPTrafico('');
    });
    common_showLayerRedirect('a%3A2%3A%7Bs%3A7%3A%22reduced%22%3BN%3Bs%3A10%3A%22ID_PROJECT%22%3Bi%3A50%3B%7D');
    window.userNumPuntos = 0.00;
    </script>
    <div class="dnone">
        <script async="" src="https://www.googletagmanager.com/gtag/js?id=AW-945252265"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'AW-945252265', { groups: 'adwords' });
        </script>
        <script>
            gtag('event', 'page_view', {"APP_CORE":1,"APP_DRESSES":0,"APP_WEDSHOOTS":1,"TOOLS_LEAD":1,"TOOLS_VENDORS_LEAD":1,"TOOLS_CHECKLIST_LEAD":1,"TOOLS_LISTA_CREATED":0,"TOOLS_GUESTS_LEAD":1,"TOOLS_TABLES_LEAD":1,"TOOLS_BUDGET_LEAD":1,"COMMUNITY_LEAD":0,"MARRIED":1,"LOGGED":1,"EMPRESA":0,"EMPRESA_CATEGORY":0,"send_to":"adwords","user_id":"u701165"});
        </script>
        <script>
            !function(f,b,e,v,n,t,s)
            {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window, document,'script',
            'https://connect.facebook.net/en_US/fbevents.js');                  
            fbq('init', '1981600325399047');
            fbq('track', 'ViewContent', {"APP_CORE":1,"APP_DRESSES":0,"APP_WEDSHOOTS":1,"TOOLS_LEAD":1,"TOOLS_VENDORS_LEAD":1,"TOOLS_CHECKLIST_LEAD":1,"TOOLS_LISTA_CREATED":0,"TOOLS_GUESTS_LEAD":1,"TOOLS_TABLES_LEAD":1,"TOOLS_BUDGET_LEAD":1,"COMMUNITY_LEAD":0,"MARRIED":1,"LOGGED":1,"EMPRESA":0,"EMPRESA_CATEGORY":0});
        </script>
        <script>
            (function() {
            !function(e){if(!window.pintrk){window.pintrk=function(){window.pintrk.queue.push(
            Array.prototype.slice.call(arguments))};var
            n=window.pintrk;n.queue=[],n.version='3.0';var
            t=document.createElement('script');t.async=!0,t.src=e;var
            r=document.getElementsByTagName('script')[0];r.parentNode.insertBefore(t,r)}}('https://s.pinimg.com/ct/core.js');

            pintrk('load', 2613710889837);
            pintrk('page');
            pintrk('track', 'custom', {"APP_CORE":"1","APP_DRESSES":"0","APP_WEDSHOOTS":"1","TOOLS_LEAD":"1","TOOLS_VENDORS_LEAD":"1","TOOLS_CHECKLIST_LEAD":"1","TOOLS_LISTA_CREATED":"0","TOOLS_GUESTS_LEAD":"1","TOOLS_TABLES_LEAD":"1","TOOLS_BUDGET_LEAD":"1","COMMUNITY_LEAD":"0","MARRIED":"1","LOGGED":"1","EMPRESA":"0","EMPRESA_CATEGORY":"0","send_to":"adwords"});
            })();
        </script>
        <script>(function(w,d,t,r,u){var f,n,i;w[u]=w[u]||[],f=function(){var o={ti: "14002286" };o.q=w[u],w[u]=new UET(o),w[u].push("pageLoad")},n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function(){var s=this.readyState;s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null)},i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)})(window,document,"script","//bat.bing.com/bat.js","uetq");</script>
    </div>
    <img class="img-trace" src="https://www.weddingwire.ca/traces-LastConnection.php?idUser=701165&amp;idDevice=2" alt="">
    <div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.515461503234821">
        <img style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.38920774797211466" alt="" src="https://bat.bing.com/action/0?ti=14002286&amp;Ver=2&amp;mid=95b53e05-a7e2-f9c3-7526-77f5467db476&amp;pi=1001431019&amp;lg=en-US&amp;sw=1366&amp;sh=768&amp;sc=24&amp;tl=Weddings,%20Wedding%20-%20Weddingwire.ca&amp;p=https%3A%2F%2Fwww.weddingwire.ca%2Ftools%2FGuestsRequestAddressForm%3Fconfirm%3D44ebe42cd12794a113c3b9f314326c0e5edb11132230e2778eac53af4d8c23e75645bc7f3be50ae2MTIxOTA2%26utm_source%3Dbodas_tools_request_confirm_address%26utm_medium%3Demail%26utm_campaign%3Dbodas_tools_request_confirm_address&amp;r=https%3A%2F%2Fmail.google.com%2Fmail%2Fu%2F1%2F&amp;lt=1049&amp;evt=pageLoad&amp;msclkid=N&amp;rn=674953" width="0" height="0">
    </div>
    <div class="layer-redirect" id="layerRedirect" style="display:;">
        <div class="wrapper pure-g">
            <div class="pure-u-2-3">
                <p class="fs16 title mb0">Welcome to weddingwire.CA </p>
                <p class="mb5 fs12 color-grey">
                    We noticed you are not in Canada, we have a version of the website for your country, do you want to take a look at it or would you rather stay?
                </p>
            </div>
            <div class="pure-u-1-3 text-right mt20">
                <a href="javascrip:void(0);" class="mr15 underline app-close-layer-redirect">Stay on weddingwire.CA</a>
                <a class="fa fa-o-chevron-right btn btn-transparent" href="https://www.weddingwire.in/utils-Redirector.php?options=a%3A2%3A%7Bs%3A7%3A%22reduced%22%3BN%3Bs%3A10%3A%22ID_PROJECT%22%3Bi%3A50%3B%7D">
                    <i class="icon-flag icon-flag-en_IN icon-right"></i> Go to www.weddingwire.in
                </a>
            </div>
            <span class="btn-close app-close-layer-redirect mr5">×</span>
        </div>
    </div>
</body>