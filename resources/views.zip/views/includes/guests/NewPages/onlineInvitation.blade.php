<table style="max-width:580px;border:1px solid #d9d9d9;border-radius:3px;margin:0 auto" width="100%" cellspacing="0" cellpadding="0">
    <tbody>
        <tr>
            <td style="background:#efefef;overflow:hidden;vertical-align:top">
                <img id="m_4853820943362533944prevHeaderImg" src="https://ci3.googleusercontent.com/proxy/RdKrOgH-LDB06BgxxABMmbIg0p614g1r5savyXs5UvDOk0B2l_i9Ar-2TEenv6hOvXbeRHjSuJrO9iYHKqzvfD2oqocC0ekQT_PPOXNczeOFDgzRXXsfgfv5wmHdh2RrDRg=s0-d-e1-ft#https://cdn0.weddingwire.ca/usr/1/1/6/5/invitation_701165_12031.jpg?r=796751754" style="display:block;max-width:100%;width:100%" class="CToWUd a6T" tabindex="0">
                <div class="a6S" dir="ltr" style="opacity: 0.01; left: 719px; top: 262px;">
                    <div id=":t0" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" role="button" tabindex="0" aria-label="Download attachment " data-tooltip-class="a1V" data-tooltip="Download">
                        <div class="aSK J-J5-Ji aYr"></div>
                    </div>
                </div>
            </td>
        </tr>
        <tr>
            <td style="padding:30px 40px 20px 40px;font-size:16px;font-weight:500;font-family:Helvetica,Arial;text-align:center;text-transform:uppercase;color:#8c8c8c;letter-spacing:1px"><span id="m_4853820943362533944prevTitulo">Testing</span></td>
        </tr>
        <tr>
            <td style="padding:0 40px 10px 40px;font-size:32px;line-height:36px;font-family:Georgia,Helvetica,Arial;text-align:center;color:#222222;line-height:1.5s"><span id="m_4853820943362533944prevNombre">Maria &amp; cesario</span></td>
        </tr>
        <tr>
            <td style="padding:0 40px 10px 40px;font-size:24px;line-height:30px;font-family:Helvetica,Arial;text-align:center;color:#222222"><span id="m_4853820943362533944prevEvent">Wedding</span></td>
        </tr>
        <tr>
            <td style="padding:0 40px 10px 40px;font-size:16px;line-height:18px;font-family:Helvetica,Arial;text-align:center;color:#222222"><span id="m_4853820943362533944prevFecha">Friday 6 of March 2015</span></td>
        </tr>
        <tr>
            <td style="padding:0 40px 5px 40px;font-size:16px;line-height:12px;font-family:Helvetica,Arial;text-align:center;color:#222222"><span id="m_4853820943362533944prevLugar">Somewhere</span></td>
        </tr>
        <tr>
            <td style="padding:20px">
                <table id="m_4853820943362533944prevTexto" width="100%" cellspacing="0" cellpadding="0">
                    <tbody>
                        <tr>
                            <td style="font-size:16px;font-family:Helvetica,Arial;line-height:25px;text-align:center;color:#222222">testing</td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        <tr id="m_4853820943362533944prevConfirm">
            <td style="text-align:center;padding:10px 40px 0">
            	<a id="m_4853820943362533944bgColorBtn" style="display:inline-block;text-decoration:none;color:#ffffff;font-weight:bold;background:#19b5bb;border:1px solid #19b5bb;border-radius:3px;padding:10px 15px;margin-bottom:10px;max-width:100%;overflow:hidden" href="https://www.weddingwire.ca/tools/GuestsRequestConfirmForm?confirm=35c98fee4b60d9a412a9646349d3977f8c436204544a53b03297f00cd9cd0fdb712659abac8dba75MTIxOTA2&amp;utm_source=bodas_invitacion_enviada&amp;utm_medium=email&amp;utm_campaign=bodas_invitacion_enviada" target="_blank"> RSVP </a>
            </td>
        </tr>
        <tr id="m_4853820943362533944prevWebsite">
            <td>
                <table style="border-top:1px solid #d9d9d9;width:580px">
                    <tbody>
                        <tr>
                            <td style="padding:30px 0 30px 70px" align="right">
                            	<img style="width:40px;height:auto;padding-right:12px" src="https://ci3.googleusercontent.com/proxy/4BB5BEAh5hbit__dp-3tbUyc6e8PUuuQjzTeYO05HcRqiecVAfrRQESHifGhAEN4Q-SZ3-EIruyMzIgsvewbPCweS2KaIVxO1HVVQ5h-lhVwOF05mrbNR18W2Q=s0-d-e1-ft#https://cdn1.weddingwire.ca/assets/img/tools/invitations/nav-wedsite.png" class="CToWUd" width="75">
                            </td>
                            <td style="overflow:hidden;font-size:14px;line-height:15px;color:#222222">
                            	<span>Visit our website</span><br>
                            	<a style="text-decoration:underline;color:#444444" href="https://www.weddingwire.ca/web/maria-and-cesario?utm_source=bodas_invitacion_enviada&amp;utm_medium=email&amp;utm_campaign=bodas_invitacion_enviada" target="_blank">https://www.weddingwire.ca/<wbr>web/maria-and-cesario</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>